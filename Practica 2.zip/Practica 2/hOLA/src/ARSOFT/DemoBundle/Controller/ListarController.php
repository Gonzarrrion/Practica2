<?php

namespace ARSOFT\DemoBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class ListarController extends Controller
{
    public function listarArticulosAction($id = 2)
    {
        $articulos = array(
    array(
        'id' => 1,
        'title' => 'Artículo 1',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 2,
        'title' => 'Artículo 2',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 3,
        'title' => 'Artículo 3',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 4,
        'title' => 'Artículo 4',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 5,
        'title' => 'Artículo 5',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 6,
        'title' => 'Artículo 6',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 7,
        'title' => 'Artículo 7',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 8,
        'title' => 'Artículo 8',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 9,
        'title' => 'Artículo 9',
        'created' => '2024-02-15'
    ),
    array(
        'id' => 10,
        'title' => 'Artículo 10',
        'created' => '2024-02-15'
    )
    );
        $articulo = isset($articulos[$id - 1]) ? $articulos[$id - 1] : null;


        return $this->render('ARSOFTDemoBundle:MisVistas:listarArticulos.html.twig', ['articulos' =>  $articulos, 'articulo' => $articulo]);        
    }
}

