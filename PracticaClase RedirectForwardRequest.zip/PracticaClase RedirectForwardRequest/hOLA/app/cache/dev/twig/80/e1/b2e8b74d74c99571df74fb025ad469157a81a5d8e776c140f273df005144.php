<?php

/* ARSOFTDemoBundle:MisVistas:listarArticulos.html.twig */
class __TwigTemplate_80e1b2e8b74d74c99571df74fb025ad469157a81a5d8e776c140f273df005144 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = array())
    {
        // line 2
        echo "    
    <h1>Listado de Articulos</h1> 
    <br>
        <table border=\"1\">
        <tr>
        <th>ID</th>
        <th>Titulo</th>
        <th>Fecha de Creacion</th> 
        </tr>
        <tr>
        <td>";
        // line 12
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "id"), "html", null, true);
        echo "</td> <td>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "title"), "html", null, true);
        echo "</td> <td>";
        echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "created"), "html", null, true);
        echo "</td>
        </tr>
        </table>
        <br><br>
        
    ";
        // line 17
        if (array_key_exists("articulo", $context)) {
            // line 18
            echo "    <table border=\"1\">
    <tr>
    <th>ARTICULOS</th>
    ";
            // line 21
            $context['_parent'] = (array) $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["articulos"]) ? $context["articulos"] : $this->getContext($context, "articulos")));
            foreach ($context['_seq'] as $context["_key"] => $context["articulo"]) {
                echo " <tr>
    <td>
        <a href=\"";
                // line 23
                echo twig_escape_filter($this->env, $this->env->getExtension('routing')->getPath("arsoft_demo_listar", array("id" => $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "id"))), "html", null, true);
                echo "\">";
                echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "title"), "html", null, true);
                echo "</a>
    </td>
    </tr>
    ";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['articulo'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 26
            echo " 
    ";
        }
        // line 28
        echo "    </table>

";
    }

    public function getTemplateName()
    {
        return "ARSOFTDemoBundle:MisVistas:listarArticulos.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  80 => 28,  76 => 26,  64 => 23,  57 => 21,  52 => 18,  50 => 17,  38 => 12,  26 => 2,  20 => 1,);
    }
}
