<?php

namespace ARSOFT\DemoBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class ARSOFTDemoBundle extends Bundle
{
}
