<?php

/* ARSOFTDemoBundle:MisVistas:vistaLista.html.twig */
class __TwigTemplate_d47729fcd2bd50139626e51ffdc36ebdee06739ac50cefe0fa72d45c3f9e4995 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        // line 1
        $this->displayBlock('body', $context, $blocks);
    }

    public function block_body($context, array $blocks = array())
    {
        // line 2
        echo "        
    <h1>Listado de Articulos</h1> 
    <table border=\"1\">
    <tr>
    <th>ID</th>
    <th>Titulo</th>
    <th>Fecha de Creacion</th> </tr>
    
    ";
        // line 10
        $context['_parent'] = (array) $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["articulos"]) ? $context["articulos"] : $this->getContext($context, "articulos")));
        foreach ($context['_seq'] as $context["_key"] => $context["articulo"]) {
            echo " <tr>
    <td>";
            // line 11
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "id"), "html", null, true);
            echo "</td> <td>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "title"), "html", null, true);
            echo "</td> <td>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "created"), "html", null, true);
            echo "</td>
    </tr>
    ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['articulo'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 13
        echo " 
    
    </table>

    
    ";
        // line 18
        if (array_key_exists("articulo", $context)) {
            // line 19
            echo "        <tr>
        <th>ID</th>
        <th>Titulo</th>
        <th>Fecha de Creacion</th> 
        </tr>
        <tr>
        <td>";
            // line 25
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "id"), "html", null, true);
            echo "</td> <td>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "title"), "html", null, true);
            echo "</td> <td>";
            echo twig_escape_filter($this->env, $this->getAttribute((isset($context["articulo"]) ? $context["articulo"] : $this->getContext($context, "articulo")), "created"), "html", null, true);
            echo "</td>
        </tr>
        </table>
    ";
        }
        // line 29
        echo "    
";
    }

    public function getTemplateName()
    {
        return "ARSOFTDemoBundle:MisVistas:vistaLista.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  83 => 29,  72 => 25,  64 => 19,  62 => 18,  55 => 13,  42 => 11,  36 => 10,  26 => 2,  20 => 1,);
    }
}
